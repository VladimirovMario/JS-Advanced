function attachEvents() {
  const baseUrl = "http://localhost:3030/jsonstore/phonebook";
  const ul = document.getElementById(`phonebook`);
  const personName = document.getElementById(`person`);
  const phoneNumber = document.getElementById(`phone`);
  const loadBtn = document.getElementById(`btnLoad`);
  const createBtn = document.getElementById(`btnCreate`);
  loadBtn.addEventListener(`click`, onLoad);
  createBtn.addEventListener(`click`, onCreate);

  async function onLoad() {
    ul.replaceChildren();

    try {
      const response = await fetch(baseUrl);
      if (response.status !== 200) {
        throw new Error(response.status);
      }

      const data = await response.json();

      for (const { person, phone, _id } of Object.values(data)) {
        const li = createEl(`li`, `${person}: ${phone}`, ul);
        li.setAttribute(`id`, _id);
        createEl(`button`, `Delete`, li, () => onDelete(_id, li));
      }
    } catch (error) {
      alert(error.message);
    }
  }

  async function onCreate() {
    if (personName.value == `` || phoneNumber.value == ``) {
      return;
    }
    const data = {
      person: personName.value,
      phone: phoneNumber.value,
    };

    try {
      const response = await fetch(baseUrl, {
        method: "post",
        headers: { "Content-type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.status !== 200) {
        throw new Error(response.status);
      }
      onLoad();
      personName.value = ``;
      phoneNumber.value = ``;
    } catch (error) {
      alert(error.message);
    }
  }

  async function onDelete(_id, li) {
    await fetch(`${baseUrl}/${_id}`, {
      method: "delete",
    });
    li.remove();
  }

  function createEl(type, content, append, addEvent) {
    const element = document.createElement(type);
    element.textContent = content;
    append.appendChild(element);
    element.addEventListener(`click`, addEvent);
    return element;
  }
}

attachEvents();
